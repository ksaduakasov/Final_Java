package com.example.demo.models;

public enum Gender {
    MALE,
    FEMALE,
    OTHER
}
